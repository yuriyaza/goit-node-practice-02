class Cars {
  add = (req, res) => {
    // res.send(req.body);
    console.log(req.body);
  };

  getAll = (req, res) => {
    res.send('getAll');
  };

  getOne = (req, res) => {
    res.send('getOne');
  };

  update = (req, res) => {
    res.send('update');
  };

  remove = (req, res) => {
    res.send('remove');
  };
}

module.exports = new Cars();
